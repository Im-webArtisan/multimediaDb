<?php
/**
 * Created by PhpStorm.
 * User: jay
 * Date: 3/31/17
 * Time: 2:28 PM
 */
echo '
        <script src="https://code.jquery.com/jquery-3.2.1.js" integrity="sha256-DZAnKJ/6XZ9si04Hgrsxu/8s717jcIzLy3oi35EouyE="
        crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js" integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30="
       crossorigin="anonymous"></script>
        <script src="http://vjs.zencdn.net/5.19.1/video.js"></script>
';
