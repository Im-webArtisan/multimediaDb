<?php
/**
 * Created by PhpStorm.
 * User: jay
 * Date: 3/31/17
 * Time: 2:27 PM
 */
echo '
<!-- bootstrap css -->
    <link rel="stylesheet" href="http://localhost/cdn/css/cyborg.css">

    <!-- custom css -->  <!--  -->
    <link rel="stylesheet" href="css/custom.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="http://vjs.zencdn.net/5.19.1/video-js.css" rel="stylesheet">

  <!-- If you'd like to support IE8 -->
  <script src="http://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>

    <!-- title caption -->
    <link rel="shortcut icon" type="image/jpg" href="images/icon.jpg">
    
    
';
