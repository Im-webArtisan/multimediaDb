<?php
/**
 * Created by PhpStorm.
 * User: jay
 * Date: 3/31/17
 * Time: 10:41 AM
 */
echo'
<!-- nav -->
            <nav class="navbar navbar-custom navbar-fixed-top" id="nav-main">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-collapse">
                            Menu <i class="fa fa-bars" aria-hidden="true"></i>
                        </button>
                        <a href="home.php" class="navbar-brand brand"><i class="fa fa-youtube-play" aria-hidden="true"></i> Artisans Entertainment</a>
                    </div>
                    <div class="collapse navbar-collapse" id="navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="search.php"><i class="fa fa-search" aria-hidden="true"></i> Search</a></li>
                            <li><a href="upload.php"><i class="fa fa-cloud-upload" aria-hidden="true"></i> Upload</a></li>
                            <li><a href="store.php"><i class="fa fa-database" aria-hidden="true"></i> Library</a></li>
                            <li><a href="logout.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Sign Out</a></li>
                        </ul>
                    </div>
                </div>
            </nav> <!--end nav  -->
';
//<form class="navbar-form navbar-left">
//    <div class="form-group">
//        <input type="text" class="form-control search" placeholder="Search">
//    </div>
//    <button type="submit" class="btn btn-default">Search</button>
//</form>